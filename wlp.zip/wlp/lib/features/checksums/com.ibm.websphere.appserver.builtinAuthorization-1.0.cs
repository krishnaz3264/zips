#Wed Jun 15 10:05:40 IST 2016
lib/com.ibm.websphere.security_1.0.12.jar=a00cf32cde46e0420f7f106dca4b088c
lib/features/builtinAuthorization-1.0.mf=61e0517f5446156995c42de8edfdd3af
lib/com.ibm.ws.security.authorization_1.0.12.jar=8800b0f9d999aec981e61e54d18ce089
lib/com.ibm.ws.security.authorization.builtin_1.0.12.jar=f648e3bad00ed108c33de620b3c510bc
