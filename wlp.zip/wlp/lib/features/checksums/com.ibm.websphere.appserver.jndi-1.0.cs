#Sat Feb 27 17:09:05 GMT 2016
lib/features/com.ibm.websphere.appserver.jndi-1.0.mf=07c95d2420d3ed4200bfe8cff003f8c0
lib/com.ibm.ws.org.apache.aries.jndi.core.1.0.3_1.1.12.jar=4e81cba787451e749f38d6b21371961f
lib/com.ibm.ws.jndi.url.contexts_1.0.12.jar=4866611b08b5cba89aacdc21e4d298b6
lib/com.ibm.ws.org.apache.aries.jndi.api.1.1.1_1.1.12.jar=5e264c32d5b99e230dd9a8f91bdf6fed
lib/com.ibm.ws.jndi_1.0.12.jar=eb693dbf1e67b963dd9763f02bf9e654
