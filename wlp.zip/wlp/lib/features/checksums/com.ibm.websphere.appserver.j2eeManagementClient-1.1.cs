#Sat Feb 27 17:09:05 GMT 2016
lib/features/j2eeManagementClient-1.1.mf=85fc3d2566ca612037e04260908a5df1
dev/api/spec/com.ibm.ws.javaee.management.j2ee.1.1_1.0.12.jar=649ab496fb296427b12835688c385456
