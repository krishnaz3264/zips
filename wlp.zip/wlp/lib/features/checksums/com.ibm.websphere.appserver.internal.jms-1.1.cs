#Wed Jun 15 11:05:15 IST 2016
lib/features/internal.jms-1.1.mf=76bb21cc4b16b269220baad3c1392583
lib/com.ibm.ws.messaging.jmsspec.common_1.0.12.jar=62a4d0a2ac3c85fd7c43f6cb97eb3436
dev/api/spec/com.ibm.ws.javaee.jms.1.1_1.0.12.jar=5449c7de82ff26f4400531373dc718b8
