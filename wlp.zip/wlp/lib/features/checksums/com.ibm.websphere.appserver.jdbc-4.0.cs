#Wed Jun 15 10:48:52 IST 2016
lib/com.ibm.ws.jdbc_1.0.12.jar=7867bdc9e583574925bc06849643882a
lib/features/jdbc-4.0.mf=5e203691ffe6032e4f49c0688b02a394
lib/com.ibm.ws.jdbc40_1.0.12.jar=4de256046657fd2a015a2712db20af0e
