#Sat Feb 27 17:09:04 GMT 2016
lib/features/jpa2.0-2.1-bv1.1.mf=59f63d330fdb1599bbf44de325789ee9
lib/com.ibm.ws.jpa.container.beanvalidation11_1.0.12.jar=d58a6466eaa9b5ea8cb9159d8a44b661
