#Sat Feb 27 17:09:04 GMT 2016
lib/features/javax.connector.internal-1.7.mf=f4bfa2132fd2d66299b05af2af8fa01d
dev/api/spec/com.ibm.ws.javaee.connector.1.7_1.0.12.jar=9cabc7a0d45879f2976103896a600b65
