#Sat Feb 27 17:09:05 GMT 2016
lib/features/cdi1.2-appSecurityClient1.0.mf=d421675385bb6155f65f0d33b4799737
lib/com.ibm.ws.cdi-1.2.client_1.0.12.jar=d06392e180f95c327ff6c44d11464085
