#Sat Feb 27 17:09:05 GMT 2016
lib/com.ibm.ws.cdi-1.2-jndi.1.0.0_1.0.12.jar=ddab4c459ec1f020c462ae935d93011c
lib/features/cdi1.2-jndi1.0.mf=429cde6307a646ba0bd66cf108a6ed3c
