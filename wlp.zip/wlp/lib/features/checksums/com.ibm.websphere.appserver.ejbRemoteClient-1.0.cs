#Sat Feb 27 17:09:04 GMT 2016
lib/com.ibm.ws.ejbcontainer.v32_1.0.12.jar=1a5e3e91a84becb58847156f067a2603
lib/com.ibm.ws.ejbcontainer.remote_1.0.12.jar=54e33dee1165e7125a1079f9b9edb46d
lib/com.ibm.ws.ejbcontainer.remote.client_1.0.12.jar=276a320af6ccc0b1006ee48a8a0001b8
clients/ejbRemotePortable.jar=516b213e269ff7fb32b811b07d4e7f22
lib/features/ejbRemoteClient-1.0.mf=c8db5faf762f8668872ceee55af88533
