#Sat Feb 27 17:09:05 GMT 2016
dev/api/spec/com.ibm.ws.javaee.transaction.1.2_1.0.12.jar=4f7f2077fc8529d12c0ee27291e38e0b
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.12.jar=3b78d9770655c18d956dd98c09d0a173
lib/features/jta-1.2.mf=e6eab799b8ff913deeab1e9ff59590ba
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=f02b43363895d799b104355320618d3d
