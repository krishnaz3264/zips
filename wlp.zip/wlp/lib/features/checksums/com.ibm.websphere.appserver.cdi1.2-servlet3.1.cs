#Wed Jun 15 10:05:43 IST 2016
lib/features/cdi1.2-servlet3.1.mf=06b2df4338901a890d763c52f14c1b38
lib/com.ibm.ws.cdi-1.2.web_1.0.12.jar=4509450c2cfaf8bc26d5da0c419070c5
dev/api/spec/com.ibm.ws.javaee.jsp.2.3_1.0.12.jar=5fca23779b404f20501263cce46f4287
