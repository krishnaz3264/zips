#Wed Jun 15 11:06:55 IST 2016
lib/com.ibm.ws.app.manager.rar_1.0.12.jar=ca7fc4e71e1a0674962a2f914f400069
lib/features/jca-1.7.mf=ad11f1a77423b481aee16930be3c2d05
lib/com.ibm.ws.jca-1.7_1.0.12.jar=57b8c2e7e1c7d088ff7efd23e5b030f7
