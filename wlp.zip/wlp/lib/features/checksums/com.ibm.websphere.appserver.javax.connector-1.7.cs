#Wed Jun 15 11:06:54 IST 2016
dev/api/spec/com.ibm.ws.javaee.connector.1.7_1.0.12.jar=9cabc7a0d45879f2976103896a600b65
lib/features/javax.connector-1.7.mf=42da2ccad19c8a40428060828ca749d2
