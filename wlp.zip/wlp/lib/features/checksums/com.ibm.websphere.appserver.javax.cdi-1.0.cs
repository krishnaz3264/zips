#Fri Jun 17 10:20:20 IST 2016
lib/features/javax.cdi-1.0.mf=035e92991cc472815684454c0f1faac5
dev/api/spec/com.ibm.ws.javaee.cdi.1.0_1.0.12.jar=cf5e18f576078b3fcd9e2c60e02ae3d0
