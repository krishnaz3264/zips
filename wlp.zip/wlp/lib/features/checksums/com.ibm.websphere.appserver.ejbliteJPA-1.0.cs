#Wed Jun 15 10:52:10 IST 2016
lib/com.ibm.ws.ejbcontainer.jpa_1.0.12.jar=21de61a3d1c0a6127933935fbfb8dce1
lib/features/ejbliteJPA-1.0.mf=160d18aa1d5229fe801802e274c6ce4d
