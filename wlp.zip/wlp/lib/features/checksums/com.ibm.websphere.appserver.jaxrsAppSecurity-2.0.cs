#Wed Jun 15 10:05:42 IST 2016
lib/com.ibm.ws.jaxrs-2.0.appSecurity_1.0.12.jar=7b88bc9de726a34012e2e47092dffca8
lib/features/jaxrsAppSecurity-2.0.mf=4fd2312cf5c97b28a310277ad09708b3
