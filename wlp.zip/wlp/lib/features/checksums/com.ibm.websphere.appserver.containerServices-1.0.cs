#Sat Feb 27 17:09:05 GMT 2016
lib/features/containerServices-1.0.mf=504aba188e7578e53ba0395acade6501
lib/com.ibm.ws.resource_1.0.12.jar=689cb537b53931bc7008bb8267cf60fb
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.containerServices_2.0-javadoc.zip=24a91752928cb80c35a4b93d46b70391
lib/com.ibm.ws.javaee.version_1.0.12.jar=213e21405c201c22e30b836efb6f6265
lib/com.ibm.ws.serialization_1.0.12.jar=7cc89157fd7c679e133eb1e2bd040ae3
lib/com.ibm.ws.container.service_1.0.12.jar=faa090c1d9fd33f4e70539adf7d39abd
dev/spi/ibm/com.ibm.websphere.appserver.spi.containerServices_2.0.12.jar=9a3967e465c58505e95bdfb51b0eef25
