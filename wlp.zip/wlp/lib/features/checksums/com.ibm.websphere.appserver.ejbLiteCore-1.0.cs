#Wed Jun 15 10:52:09 IST 2016
lib/features/ejbLiteCore-1.0.mf=5b71f12e706a6885f7a0618f8c2aabe5
lib/com.ibm.ws.ejbcontainer.session_1.0.12.jar=a280b6b4dd724f9192840ee0fb35f389
