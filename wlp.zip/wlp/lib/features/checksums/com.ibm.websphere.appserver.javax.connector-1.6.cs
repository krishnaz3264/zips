#Wed Jun 15 11:05:14 IST 2016
dev/api/spec/com.ibm.ws.javaee.connector.1.6_1.0.12.jar=95acbd123e4969c1acc635388348d737
lib/features/javax.connector-1.6.mf=3ad6045ddc658e301ac5a0bff29a6457
