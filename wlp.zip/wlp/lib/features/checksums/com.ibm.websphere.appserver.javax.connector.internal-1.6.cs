#Sat Feb 27 17:09:05 GMT 2016
lib/features/javax.connector.internal-1.6.mf=0ef391994df6183a3b1654660444dc41
dev/api/spec/com.ibm.ws.javaee.connector.1.6_1.0.12.jar=95acbd123e4969c1acc635388348d737
