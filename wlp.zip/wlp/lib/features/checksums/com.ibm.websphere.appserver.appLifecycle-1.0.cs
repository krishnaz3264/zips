#Sat Feb 27 17:09:04 GMT 2016
lib/features/appLifecycle-1.0.mf=f81446ffdc94bc6da27c89e1e87ee485
lib/com.ibm.ws.app.manager.lifecycle_1.0.12.jar=928fa870cb9aedd30b85018cf6b1a8ae
