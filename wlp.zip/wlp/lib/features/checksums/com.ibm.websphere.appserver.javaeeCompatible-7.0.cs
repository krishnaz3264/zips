#Sat Feb 27 17:09:05 GMT 2016
lib/com.ibm.ws.javaee.version_1.0.12.jar=213e21405c201c22e30b836efb6f6265
lib/features/javaeeCompatible-7.0.mf=a00c60f882f1ac21c3966e7417ee6d86
