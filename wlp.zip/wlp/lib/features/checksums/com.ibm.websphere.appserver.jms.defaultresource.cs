#Wed Jun 15 11:12:57 IST 2016
lib/com.ibm.ws.messaging.jms.defaultresource_1.0.12.jar=794a2f441a74440b8ad8880cf7b28a63
lib/features/jms.defaultresource.mf=b45ffc8450c3c6e5d5d4fe13b5472bb8
