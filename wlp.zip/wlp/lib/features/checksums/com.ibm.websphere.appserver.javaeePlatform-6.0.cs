#Sat Feb 27 17:09:06 GMT 2016
lib/features/javaeePlatform-6.0.mf=eea823a6b200e9750ff83ff2602480e4
lib/com.ibm.ws.javaee.version_1.0.12.jar=213e21405c201c22e30b836efb6f6265
lib/com.ibm.ws.app.manager.module_1.0.12.jar=71927ac0c1bca2bc0c99354c3eb4fa7b
lib/com.ibm.ws.security.java2sec_1.0.12.jar=2d8cd7d128ef45cbd46f260b541c9e88
