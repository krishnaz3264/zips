#Sat Feb 27 17:09:04 GMT 2016
lib/com.ibm.ws.context_1.0.12.jar=1c051ce3ff10fa75f45318e0020230ee
lib/com.ibm.ws.resource_1.0.12.jar=689cb537b53931bc7008bb8267cf60fb
lib/features/contextService-1.0.mf=f6af7849b95d5270c549f7261c13efeb
