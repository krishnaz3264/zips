#Wed Jun 15 10:52:10 IST 2016
lib/com.ibm.ws.jaxws.ejb_1.0.12.jar=476e3d2a9bc71e8e28061c6b74202c5d
lib/features/jaxwsejb-2.2.mf=8c2a0d473965b521197ca6fb933cc2f0
