#Wed Jun 15 10:05:38 IST 2016
lib/com.ibm.ws.jaxrs-2.0.managedBeans_1.0.12.jar=d24a310c323154d7a3f770b96b2f8691
lib/features/jaxrs20ManagedBeans-1.0.mf=6a6f8fce24baed3e053acf5d75258cd1
