#Sat Feb 27 17:09:05 GMT 2016
dev/api/spec/com.ibm.ws.javaee.cdi.1.2_1.2.12.jar=aea678e42d6230ee6700fe3ea5ec55f1
lib/features/javax.cdi-1.2.mf=6bb9ffcb00f3f1414408792bc5aea70c
