#Fri Jun 17 10:20:20 IST 2016
lib/features/jaxrsCDI-1.1.mf=abd1cb8337e0a8d3e2513453041bf390
lib/com.ibm.ws.jaxrs.cdi_1.0.12.jar=d93dcbecc27eca9b895458e2f44f5b60
