#Sat Feb 27 17:09:05 GMT 2016
dev/api/spec/com.ibm.ws.javaee.jms.2.0_1.0.12.jar=64d5bb5364a9bc81882e23ada202fd37
lib/features/com.ibm.websphere.appserver.internal.jms-2.0.mf=d17bb67a3b41e0da6564876ee7b16c7f
lib/com.ibm.ws.messaging.jmsspec.common_1.0.12.jar=62a4d0a2ac3c85fd7c43f6cb97eb3436
