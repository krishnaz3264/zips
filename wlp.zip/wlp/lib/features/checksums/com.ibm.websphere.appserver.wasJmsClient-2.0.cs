#Sat Feb 27 17:09:04 GMT 2016
lib/com.ibm.ws.messaging.common_1.0.12.jar=512930ba498637ecd3d6208539ec31b2
lib/com.ibm.ws.messaging.jms.common_1.0.12.jar=8ce6c5e436f3ede48972bb278493e9eb
lib/com.ibm.ws.resource_1.0.12.jar=689cb537b53931bc7008bb8267cf60fb
lib/com.ibm.ws.messaging.comms.client_1.0.12.jar=f6a7c9ba67089076f381a489a86744f7
lib/features/com.ibm.websphere.appserver.wasJmsClient-2.0.mf=25914d221aa1bf15493c76b0a7610fd4
lib/com.ibm.ws.messaging.utils_1.0.12.jar=86beb443972f216e6f487a99adc51cb4
lib/com.ibm.ws.messaging.jms-2.0_2.0.12.jar=9ab2c9649daa69d4b1a102e7c98c9a02
