#Sat Feb 27 17:09:04 GMT 2016
lib/com.ibm.ws.timer_1.0.12.jar=efbe063482cd16c1dbc3c720de8f6e26
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.endpoint_1.0-javadoc.zip=9cd0fb9126e3aba5feb8ad6530318537
dev/api/ibm/com.ibm.websphere.appserver.api.endpoint_1.0.12.jar=2cb9a2f127c1d5657d3835a851d0a162
lib/com.ibm.ws.channelfw_1.0.12.jar=a910c1cda403c1f62dcb5d16829d8db7
lib/features/channelfw-1.0.mf=551a29029e85f3222af15cb7a6eb4977
