#Sat Feb 27 17:09:04 GMT 2016
lib/features/injection-1.0.mf=5fed432a01fecf0ab603f2d1042bb6c8
lib/com.ibm.ws.injection_1.0.12.jar=fea3adcdc82c5f88146fa792ef3dc0c9
