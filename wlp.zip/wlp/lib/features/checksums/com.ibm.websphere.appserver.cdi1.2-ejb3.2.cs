#Sat Feb 27 17:09:05 GMT 2016
lib/features/cdi1.2-ejb3.2.mf=562a45713eac500b23ca081a1e3d994d
lib/com.ibm.ws.cdi-1.2.ejb_1.0.12.jar=1362daf8eb94b6afd77c46a8e5b3bb6c
