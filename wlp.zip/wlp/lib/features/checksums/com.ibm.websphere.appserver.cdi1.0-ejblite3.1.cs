#Fri Jun 17 10:20:20 IST 2016
lib/com.ibm.ws.openwebbeans-ejb.1.1.6_1.0.12.jar=93e2355fb4b9493ad967a13ffadb919c
lib/features/cdi1.0-ejblite3.1.mf=647d9cace015c458307ce785358b4cff
lib/com.ibm.ws.openwebbeans-ee-common.1.1.6_1.0.12.jar=db8195cc97f91e4b91fc4a5ebdb03d66
