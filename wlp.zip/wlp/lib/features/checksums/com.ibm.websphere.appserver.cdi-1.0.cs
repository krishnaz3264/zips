#Fri Jun 17 10:20:20 IST 2016
dev/api/ibm/schema/ibm-managed-bean-bnd_1_0.xsd=914d243e72b5fdf8dfbff4f6be3e4bc9
lib/com.ibm.ws.openwebbeans-spi.1.1.6_1.0.12.jar=91ccb25408b1de49ddfac79ae55546e0
lib/com.ibm.ws.managedobject_1.0.12.jar=5502ea5d595a24f518d1b88dbd93d4ca
lib/features/cdi-1.0.mf=2f454bd9ca14c6a2114e496307174f93
dev/api/ibm/schema/ibm-managed-bean-bnd_1_1.xsd=d90f6abac37958438d8018aa10797eee
lib/com.ibm.ws.openwebbeans-impl.1.1.6_1.0.12.jar=5d47f6a86054746393426f6eddcf3d24
lib/com.ibm.ws.javassist.3.13.0_1.0.12.jar=2730cef6caef4e7c860646a2ce57d65a
