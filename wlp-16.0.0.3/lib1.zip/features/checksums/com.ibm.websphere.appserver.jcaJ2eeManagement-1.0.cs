#Tue Nov 01 15:10:51 IST 2016
lib/com.ibm.ws.jca.management.j2ee_1.0.14.jar=c02c534268e0da7863d82ec8f4ad3907
lib/features/com.ibm.websphere.appserver.jcaJ2eeManagement-1.0.mf=8e930b5aca36468b6a658d33ec949127
