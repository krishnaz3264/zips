#Tue Nov 01 14:44:47 IST 2016
lib/com.ibm.ws.wsoc_1.0.14.jar=5e9ed2a0ef3d543ca045701ad142efa7
lib/features/com.ibm.websphere.appserver.websocket-1.0.mf=97593e8eb6d8b21fc9c2404643ef225a
dev/api/spec/com.ibm.ws.javaee.websocket.1.0_1.0.14.jar=2fc66659b4db9cede53d66ef77d2652f
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.wsoc_1.0-javadoc.zip=b8acdbb529ce5a4e0073b21b19bcf455
dev/api/ibm/com.ibm.websphere.appserver.api.wsoc_1.0.14.jar=3051208a4eba0e10934bd844c6b84608
