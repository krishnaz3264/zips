#Tue Nov 01 15:12:28 IST 2016
lib/features/com.ibm.websphere.appserver.javaMail-1.5.mf=0dfcde24cdfc7d203000067b543f0707
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.mail_1.0.14.jar=74d307c3b2e6c493ff80b41678c1fd4f
dev/api/spec/com.ibm.ws.javaee.mail.1.5_1.0.14.jar=522e91d5264116ad6b59c262ecf3a3d4
lib/com.ibm.ws.javamail_1.5.14.jar=e7d551163e0a663dd46cc45a6ef7563e
