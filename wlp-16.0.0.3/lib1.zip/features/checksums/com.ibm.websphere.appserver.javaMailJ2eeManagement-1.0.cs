#Tue Nov 01 15:12:29 IST 2016
lib/com.ibm.ws.javamail.management.j2ee_1.0.14.jar=dca853972d6aa6f4abd09cace296bfd6
lib/features/com.ibm.websphere.appserver.javaMailJ2eeManagement-1.0.mf=11b09da359717acd2152b427477b8cc3
