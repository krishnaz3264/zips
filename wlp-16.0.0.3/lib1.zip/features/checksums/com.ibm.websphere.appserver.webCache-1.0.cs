#Wed Aug 31 18:57:16 BST 2016
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.webCache_1.1-javadoc.zip=a1fdd6d4fba13739010c40b6f158de71
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.webCache_1.0-javadoc.zip=c2da8a2e754c17d2fb17f13ff55c14e9
dev/api/ibm/com.ibm.websphere.appserver.api.webCache_1.1.14.jar=2067edbef74a3c85df39927e5f7046e0
lib/com.ibm.ws.dynacache.web_1.0.14.jar=13f5e061b7cbeafc1fcbe0463b32fa3a
dev/api/ibm/schema/cachespec.xsd=4c363b074382cb0c1762f596c91bdfa4
dev/spi/ibm/com.ibm.websphere.appserver.spi.webCache_1.0.14.jar=ac3aa88b25870069fffd0279850ad9e1
lib/features/com.ibm.websphere.appserver.webCache-1.0.mf=3e054f538e2133c7b59d2a2911efaaff
