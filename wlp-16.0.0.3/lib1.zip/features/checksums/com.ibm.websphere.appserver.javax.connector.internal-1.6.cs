#Wed Aug 31 18:57:16 BST 2016
lib/features/com.ibm.websphere.appserver.javax.connector.internal-1.6.mf=35c6033973b1f05e7b66cc84a641387e
dev/api/spec/com.ibm.ws.javaee.connector.1.6_1.0.14.jar=05cef87bfebf55fd8b20ff1f4b5f60a0
