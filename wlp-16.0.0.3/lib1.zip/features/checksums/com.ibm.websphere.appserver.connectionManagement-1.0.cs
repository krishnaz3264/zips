#Wed Aug 31 18:57:16 BST 2016
lib/com.ibm.ws.jca.cm_1.0.14.jar=718555878482a2b6aebf8f60d84accb1
lib/features/com.ibm.websphere.appserver.connectionManagement-1.0.mf=816dbe4bd6bc972e43e694a634989810
lib/com.ibm.ws.tx.zos_1.0.14.jar=f687ef30a2c750e955994bd8392f766d
