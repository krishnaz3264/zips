#Wed Aug 31 18:57:16 BST 2016
lib/com.ibm.ws.jpa.container.v21.cdi_1.0.14.jar=111f91b789a0117bdf7880740daca287
lib/features/com.ibm.websphere.appserver.jpa2.1-cdi1.2.mf=2fc5a05ddeeb699545114fe30b8f4620
