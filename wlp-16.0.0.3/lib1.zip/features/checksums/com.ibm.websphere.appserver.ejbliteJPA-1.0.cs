#Wed Aug 31 18:57:16 BST 2016
lib/features/com.ibm.websphere.appserver.ejbliteJPA-1.0.mf=b6454cca6d6047cfa201893164cf657c
lib/com.ibm.ws.ejbcontainer.jpa_1.0.14.jar=354aea0d4ede4819e2c04218feb8a776
