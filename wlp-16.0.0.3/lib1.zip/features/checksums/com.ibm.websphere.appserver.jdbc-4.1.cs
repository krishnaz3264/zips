#Wed Aug 31 18:57:16 BST 2016
lib/com.ibm.ws.jdbc_1.0.14.jar=a5f2c2fb4ae662a191e4206baaa50e1f
lib/com.ibm.ws.jdbc41_1.0.14.jar=b7bd5e5c73b9e629d1caa494c7dcbf86
lib/features/com.ibm.websphere.appserver.jdbc-4.1.mf=86ad7342ba7333be423b16c19205c005
