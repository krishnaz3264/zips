#Wed Aug 31 18:57:16 BST 2016
dev/api/ibm/com.ibm.websphere.appserver.api.distributedMap_2.0.14.jar=688301827fdca76a81cb82e05f288b08
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.distributedMap_2.0-javadoc.zip=a5bfb5f8aa635cfb959119cd0c3d0651
lib/features/com.ibm.websphere.appserver.distributedMap-1.0.mf=e79b098dbd35280af7cca3bf1b05b8bb
lib/com.ibm.ws.dynacache_1.0.14.jar=66439cf2ed88e662119b4e789ffa2c13
