#Tue Nov 01 15:10:47 IST 2016
lib/features/com.ibm.websphere.appserver.jndiJ2eeManagement-1.0.mf=5c72e4efebae3f72db94c4905f990ee5
lib/com.ibm.ws.jndi.management.j2ee_1.0.14.jar=52a69a8cc88b19bde46004e17a30d4e4
