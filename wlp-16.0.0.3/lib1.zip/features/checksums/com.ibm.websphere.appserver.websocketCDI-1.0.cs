#Tue Nov 01 14:35:28 IST 2016
lib/com.ibm.ws.wsoc.cdi_1.0.14.jar=2c73e15915c0ff49e34cf85161451b3b
lib/features/com.ibm.websphere.appserver.websocketCDI-1.0.mf=ec9a603040631f5ab0fd7508209a6e53
