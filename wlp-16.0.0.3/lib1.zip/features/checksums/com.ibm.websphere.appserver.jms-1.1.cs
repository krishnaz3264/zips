#Tue Nov 01 14:50:28 IST 2016
lib/features/com.ibm.websphere.appserver.jms-1.1.mf=41266f68895193c092ed4932158c4d53
lib/com.ibm.ws.jms.feature_1.0.14.jar=226b424291c90887bc2590e7e5386d63
