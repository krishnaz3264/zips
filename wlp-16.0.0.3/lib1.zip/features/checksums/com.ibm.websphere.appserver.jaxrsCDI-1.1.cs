#Tue Nov 01 14:46:43 IST 2016
lib/com.ibm.ws.jaxrs.cdi_1.0.14.jar=56be5b7f012c579df8829dcda35e4429
lib/features/com.ibm.websphere.appserver.jaxrsCDI-1.1.mf=ef70a372c270a047b8f40956a145d70f
