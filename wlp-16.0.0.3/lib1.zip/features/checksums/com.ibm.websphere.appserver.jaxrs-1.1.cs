#Tue Nov 01 14:46:41 IST 2016
lib/features/com.ibm.websphere.appserver.jaxrs-1.1.mf=f52cad8dfa47abde243ce220d92966c6
