#Wed Aug 31 18:57:16 BST 2016
lib/features/com.ibm.websphere.appserver.internal.jaxrs-1.1.mf=590acfa27e3a1c968b5b564ecdf5e1fe
lib/com.ibm.ws.org.apache.commons.lang.2.4_1.0.14.jar=0567390140b1ef79ad2c4291c1150cb0
dev/api/spec/com.ibm.ws.javaee.jaxrs.1.1_1.0.14.jar=b3d1da93b8bf275bf543e70bf81e5f2a
dev/api/ibm/com.ibm.websphere.appserver.api.jaxrs_1.0.14.jar=feeb0ca9a753687849ce0387d9243a5a
lib/com.ibm.ws.jaxrs_1.0.14.jar=91a903e28e4173bafe6510b7b8912904
lib/com.ibm.ws.org.apache.commons.codec.1.4_1.0.14.jar=c5d32bbd434cb7607b6ba95cc896fe75
lib/com.ibm.ws.org.apache.commons.logging.1.0.3_1.0.14.jar=90834a983398a51631b15c8bc5d3b048
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.jaxrs_1.0.14.jar=b0e8ce27fd34bf3be5e25bf643ad4359
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.jaxrs_1.0-javadoc.zip=d2adb2b67f2cbe32f0a9c06b6c0c4dca
