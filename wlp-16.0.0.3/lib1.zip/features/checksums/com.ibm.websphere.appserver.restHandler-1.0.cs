#Wed Aug 31 18:57:16 BST 2016
lib/com.ibm.ws.rest.handler_1.0.14.jar=799218adde73f4e96424c61ea0ba6f64
lib/com.ibm.websphere.rest.handler_1.0.14.jar=c6689f8116da4495c032096bcb870ecb
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.restHandler_1.5-javadoc.zip=70e7f34fd383c86084006fe460a4ece9
dev/spi/ibm/com.ibm.websphere.appserver.spi.restHandler_1.5.14.jar=1e1dc9713d606bc9d3aaf418d0faf4c4
lib/features/com.ibm.websphere.appserver.restHandler-1.0.mf=6025f4b5d947003e1ce6132491c3a3ea
lib/com.ibm.ws.joda-time.1.6.2_1.0.14.jar=1629d23ed62530597a5b5ed8540cd7b6
lib/com.ibm.websphere.rest.api.discovery_1.0.14.jar=d931ab9d0f42cd706c955abb5770e109
lib/com.ibm.websphere.collective.plugins_1.0.14.jar=cc9de4f8801a88c6ab1b4d6d061e3987
lib/com.ibm.websphere.jsonsupport_1.0.14.jar=e14e4e19decf848e472edde2575c19e6
