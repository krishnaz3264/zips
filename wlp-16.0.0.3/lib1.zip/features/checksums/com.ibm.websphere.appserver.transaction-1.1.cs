#Wed Aug 31 18:57:15 BST 2016
lib/features/com.ibm.websphere.appserver.transaction-1.1.mf=775f926e7aa0fd5bbe86e55bd20cbea6
lib/com.ibm.tx.util_1.0.14.jar=aac10ca18462b85ea255d8e24802f394
lib/com.ibm.ws.tx.jta.extensions_1.0.14.jar=c8b31053dd26515ae0de154294e6648f
lib/com.ibm.ws.recoverylog_1.0.14.jar=e9ee50e581ccb4e4ae143587e4329929
lib/com.ibm.rls.jdbc_1.0.14.jar=30d04fc75b90ef1f949ac69f0e87ad55
dev/spi/ibm/com.ibm.websphere.appserver.spi.transaction_1.1.14.jar=272e01c4e5ae4246139a33a877648988
lib/com.ibm.ws.transaction_1.0.14.jar=858655a029719aea841b25e95d676113
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.transaction_1.1-javadoc.zip=56dc08bd0c5682e43b62184c8e1a799e
lib/com.ibm.tx.jta_1.0.14.jar=52b5e1dac881a3432fd508301c60fbf9
lib/com.ibm.ws.tx.embeddable_1.0.14.jar=7439a159960f97951c510859c8f05b89
lib/com.ibm.tx.ltc_1.0.14.jar=1eca31752e84e8ac6afde710f6468092
