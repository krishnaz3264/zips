#Wed Aug 31 18:57:16 BST 2016
lib/com.ibm.ws.javaee.persistence.2.1_1.0.14.jar=34ecc97efb7c19ef0feda57c733a3d94
lib/features/com.ibm.websphere.appserver.javax.persistence.base-2.1.mf=b6058d38007973b2ba0a55b5fed3d13f
