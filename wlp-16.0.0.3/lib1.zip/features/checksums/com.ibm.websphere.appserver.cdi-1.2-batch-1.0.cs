#Tue Nov 01 15:01:16 IST 2016
lib/features/com.ibm.websphere.appserver.cdi-1.2-batch-1.0.mf=0916a533742ef6d0a671a620d74f64e0
lib/com.ibm.ws.jbatch.cdi_1.0.14.jar=6863203dddac64daa97e30401ffcd85e
