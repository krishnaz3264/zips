#Wed Aug 31 18:57:16 BST 2016
lib/features/com.ibm.websphere.appserver.json-1.0.mf=bc4046150f987045110af1cc50e4c53b
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.json_1.0-javadoc.zip=58cb87efbbb282c9367053f9672c1821
dev/api/ibm/com.ibm.websphere.appserver.api.json_1.0.14.jar=e7ab5f0175c5e7c982cc100fc9cf8d72
lib/com.ibm.json4j_1.0.14.jar=f25d8da7ef4dacc48aeade95ec9f14e5
