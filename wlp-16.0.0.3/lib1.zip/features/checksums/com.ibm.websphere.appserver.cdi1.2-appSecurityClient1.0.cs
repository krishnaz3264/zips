#Tue Nov 01 14:32:09 IST 2016
lib/features/com.ibm.websphere.appserver.cdi1.2-appSecurityClient1.0.mf=ace206e946f83155557999a79b652462
lib/com.ibm.ws.cdi-1.2.client_1.0.14.jar=f323ce15830dd192031b9a9428f2ccad
