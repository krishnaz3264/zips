#Wed Aug 31 18:57:17 BST 2016
lib/features/com.ibm.websphere.appserver.restConnectorjaxrs-1.0.mf=7fded0d60afba427a43cf1a0065ee9dd
