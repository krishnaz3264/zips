#Wed Aug 31 18:57:17 BST 2016
lib/features/com.ibm.websphere.appserver.microProfile-1.0.mf=1bce4a87ff5a47b1678d0a1aee2b137a
lib/com.ibm.ws.require.java8_1.0.14.jar=5eab37b21b82bef333efb1a0a9761190
