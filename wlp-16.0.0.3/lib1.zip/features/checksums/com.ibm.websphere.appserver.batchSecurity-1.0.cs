#Tue Nov 01 15:01:15 IST 2016
lib/features/com.ibm.websphere.appserver.batchSecurity-1.0.mf=faf9c393187b96c65579402a7071d1d4
lib/com.ibm.ws.jbatch.security_1.0.14.jar=973eedb43c81e9dc9f90d6db15b5262b
