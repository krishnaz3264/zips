#Tue Nov 01 15:10:48 IST 2016
lib/com.ibm.ws.jdbc.management.j2ee_1.0.14.jar=371af64121e9ad0928801f61ab5db306
lib/features/com.ibm.websphere.appserver.jdbcJ2eeManagement-1.0.mf=c5a04ac8fa8a2e8ef06b5d48557a03fd
