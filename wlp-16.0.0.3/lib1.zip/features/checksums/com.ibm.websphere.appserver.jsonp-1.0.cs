#Wed Aug 31 18:57:16 BST 2016
dev/api/spec/com.ibm.ws.javaee.jsonp.1.0_1.0.14.jar=99a2d6eb8aceb9c6bb710fa8390ef20e
lib/com.ibm.ws.org.glassfish.json.1.0_1.0.14.jar=f8c691644683ad9dc62b5c8dce72ea3b
lib/features/com.ibm.websphere.appserver.jsonp-1.0.mf=f2dc8dedb96429c66cbd92585acd8434
