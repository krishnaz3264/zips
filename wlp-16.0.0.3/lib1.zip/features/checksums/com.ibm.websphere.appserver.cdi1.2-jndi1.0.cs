#Wed Aug 31 18:57:17 BST 2016
lib/com.ibm.ws.cdi-1.2-jndi.1.0.0_1.0.14.jar=2e57c064305c5df0d0efa5cb3aa0cd3b
lib/features/com.ibm.websphere.appserver.cdi1.2-jndi1.0.mf=dd99b70712743ec4731580a178bb2fdc
