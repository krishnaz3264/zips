#Wed Aug 31 18:57:16 BST 2016
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.httptransport_1.1-javadoc.zip=0ab306bf126c25b9aa299828b88164f9
dev/spi/ibm/com.ibm.websphere.appserver.spi.httptransport_1.1.14.jar=956ff31fb08cbf7fe0850fd46d0f6717
lib/com.ibm.ws.transport.http_1.0.14.jar=ae1631f44e54b177342febd91536796b
lib/features/com.ibm.websphere.appserver.httptransport-1.0.mf=927ade37564a7ef1924ed52bed455a18
