#Tue Nov 01 15:12:38 IST 2016
lib/com.ibm.ws.cdi-1.2.jms_1.0.14.jar=9f8d321cfe3a259baf32a244d185e26d
lib/features/com.ibm.websphere.appserver.cdi1.2-jms-2.0.mf=b6d6cd1f5aae5b90b6b0c891ca78fa2b
