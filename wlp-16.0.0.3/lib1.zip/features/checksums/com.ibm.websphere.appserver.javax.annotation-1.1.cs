#Wed Aug 31 18:57:16 BST 2016
lib/features/com.ibm.websphere.appserver.javax.annotation-1.1.mf=f9a5dfb0252ddc29e102fcd63405ba52
dev/api/spec/com.ibm.ws.javaee.annotation.1.1_1.0.14.jar=2fa1059209c3293c046687286f36fd2c
