#Wed Aug 31 18:57:16 BST 2016
lib/features/com.ibm.websphere.appserver.jaxrsApiStub-1.1.mf=94127f0a251446d12bd9e0d5a093b74d
dev/api/third-party/com.ibm.ws.jaxrs.api_1.0.14.jar=379d583bd58a700dfad6c5679a36797d
