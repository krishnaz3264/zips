#Tue Nov 01 14:35:19 IST 2016
lib/features/com.ibm.websphere.appserver.javax.cdi-1.0.mf=6104893969b53cf13ea18548efd8ff28
dev/api/spec/com.ibm.ws.javaee.cdi.1.0_1.0.14.jar=a82df0d0d74c1804feb6a5ef4e20f79a
