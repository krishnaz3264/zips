#Wed Aug 31 18:57:17 BST 2016
lib/features/com.ibm.websphere.appserver.jaxrscdi-2.0.mf=3543fbd641b350c8055b42a3e685bedc
lib/com.ibm.ws.jaxrs-2.0.cdi_1.0.14.jar=c0b49e62f10545c60f3fabd0414d77de
