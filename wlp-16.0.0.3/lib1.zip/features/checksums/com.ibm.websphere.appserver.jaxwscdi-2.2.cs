#Tue Nov 01 14:47:54 IST 2016
lib/features/com.ibm.websphere.appserver.jaxwscdi-2.2.mf=619e0889d41097484af6910b34bdba09
lib/com.ibm.ws.jaxws.cdi_1.0.14.jar=d624ce04ac9bc90b9f602407ef435d6a
