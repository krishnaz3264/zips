#Wed Aug 31 18:57:16 BST 2016
dev/api/spec/com.ibm.ws.javaee.ejb.3.2_1.0.14.jar=0c0813e86ba10935f932d28aa3f808d0
lib/features/com.ibm.websphere.appserver.javax.ejb-3.2.mf=5aeca4508a680d2b21b13ea47d34d9ac
