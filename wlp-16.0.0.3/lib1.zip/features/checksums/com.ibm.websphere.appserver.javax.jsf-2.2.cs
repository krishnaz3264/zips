#Wed Aug 31 18:57:16 BST 2016
lib/features/com.ibm.websphere.appserver.javax.jsf-2.2.mf=35ba03932a8afc32b7a4f08c15f9e941
dev/api/spec/com.ibm.ws.javaee.jsf.2.2_1.0.14.jar=cab7a384600c03280028963b1548321a
