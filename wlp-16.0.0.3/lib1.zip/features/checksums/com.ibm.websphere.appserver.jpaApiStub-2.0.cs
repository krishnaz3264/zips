#Tue Nov 01 14:38:21 IST 2016
lib/features/com.ibm.websphere.appserver.jpaApiStub-2.0.mf=bff59823d5084fcf0ec0d4c5f76a6c19
dev/api/third-party/com.ibm.ws.jpa_1.2.14.jar=fc084c70d8c2b25004831096868f08a6
