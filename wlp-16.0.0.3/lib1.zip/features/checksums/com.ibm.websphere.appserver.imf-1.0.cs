#Tue Nov 01 15:24:00 IST 2016
lib/features/com.ibm.websphere.appserver.imf-1.0.mf=90ab173bbfc20aced1cbeeb9d0b654c0
lib/com.ibm.ws.imf.autoScaling_1.0.14.jar=df84eba5c889b5797b1f65e70a2034bb
lib/com.ibm.ws.imf_1.0.14.jar=e4b866c1a543eb64a3f1634bbed9bad5
