#Tue Nov 01 15:12:37 IST 2016
dev/api/spec/com.ibm.ws.javaee.jacc.1.5_1.0.14.jar=e1daf41ddeea67a0c0c3e319357ddf14
lib/com.ibm.ws.security.authorization.jacc.ejb_1.0.14.jar=7c46645b626bf648ed5be6dad0bff8ee
lib/features/com.ibm.websphere.appserver.jaccEjb-1.5.mf=f4468cfe039c838b63e7eb1436bb297d
