#Wed Aug 31 18:57:17 BST 2016
lib/com.ibm.ws.session.monitor_1.0.14.jar=144e38fffd7a1ee67778e358a232df04
dev/api/ibm/com.ibm.websphere.appserver.api.sessionstats_1.0.14.jar=5e5cf93d308ca1694d6ff93b039a16c9
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.sessionstats_1.0-javadoc.zip=0de8ff0d92a81286a25d5dc7812681e9
lib/features/com.ibm.websphere.appserver.sessionMonitor-1.0.mf=178415127047d1bef1f5a8eea3ab0bae
