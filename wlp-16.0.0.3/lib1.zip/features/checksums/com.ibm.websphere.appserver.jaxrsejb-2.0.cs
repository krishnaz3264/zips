#Wed Aug 31 18:57:16 BST 2016
lib/features/com.ibm.websphere.appserver.jaxrsejb-2.0.mf=cfdeff777249025952dc564047478eb1
lib/com.ibm.ws.jaxrs-2.0.ejb_1.0.14.jar=57569e1b6f346c3303206bf9fab16bc4
