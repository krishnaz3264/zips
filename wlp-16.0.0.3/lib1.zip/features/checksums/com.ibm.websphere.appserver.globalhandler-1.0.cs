#Wed Aug 31 18:57:15 BST 2016
lib/features/com.ibm.websphere.appserver.globalhandler-1.0.mf=e7ccda492f3bf4be2e71e5d842c56bee
lib/com.ibm.webservices.handler_1.0.14.jar=7a366e992962a2da3bffef1123fe2971
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.globalhandler_1.0-javadoc.zip=44fe58a86c9e8e3ad474609fd2b574b4
dev/spi/ibm/com.ibm.websphere.appserver.spi.globalhandler_1.0.14.jar=94197e340d881100fcd6926c5d1acf47
