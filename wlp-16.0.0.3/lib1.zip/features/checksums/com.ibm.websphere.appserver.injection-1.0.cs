#Wed Aug 31 18:57:17 BST 2016
lib/features/com.ibm.websphere.appserver.injection-1.0.mf=0fbf6e7ab8db7679cc5576352d13b07f
lib/com.ibm.ws.injection_1.0.14.jar=8d6b736d14305f590fb1abbb54c99805
