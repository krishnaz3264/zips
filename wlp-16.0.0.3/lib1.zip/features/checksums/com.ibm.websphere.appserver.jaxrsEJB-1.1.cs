#Tue Nov 01 14:46:42 IST 2016
lib/com.ibm.ws.jaxrs.ejb_1.0.14.jar=3a4999c30779eb1f03651c2292388fdf
lib/features/com.ibm.websphere.appserver.jaxrsEJB-1.1.mf=fa5d9d249b16434ab4bb2891177d285c
