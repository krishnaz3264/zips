#Wed Aug 31 18:57:16 BST 2016
lib/features/com.ibm.websphere.appserver.securityContext-1.0.mf=f1f29f74594dfb5ceb27e5b4be1dfb0a
lib/com.ibm.ws.security.context_1.0.14.jar=deb02933f1b7dc80f999f50566b601e3
