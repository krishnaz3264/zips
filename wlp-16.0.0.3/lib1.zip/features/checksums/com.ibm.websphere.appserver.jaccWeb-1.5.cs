#Tue Nov 01 15:12:32 IST 2016
lib/com.ibm.ws.security.authorization.jacc.web_1.0.14.jar=79fb7fc542771d776c0c4f2fa3ac70bf
lib/features/com.ibm.websphere.appserver.jaccWeb-1.5.mf=c4bd6a8203700010d20a6f90d9010f63
dev/api/spec/com.ibm.ws.javaee.jacc.1.5_1.0.14.jar=e1daf41ddeea67a0c0c3e319357ddf14
