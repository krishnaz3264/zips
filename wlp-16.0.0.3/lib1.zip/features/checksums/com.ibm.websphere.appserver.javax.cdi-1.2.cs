#Wed Aug 31 18:57:16 BST 2016
dev/api/spec/com.ibm.ws.javaee.cdi.1.2_1.2.14.jar=0b2b26ce67ead3c7dc68fad545081f70
lib/features/com.ibm.websphere.appserver.javax.cdi-1.2.mf=f2027d89f1b39c775354f33c93b2b8b1
