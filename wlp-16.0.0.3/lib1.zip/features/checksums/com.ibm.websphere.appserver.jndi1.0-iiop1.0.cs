#Tue Nov 01 14:27:49 IST 2016
lib/com.ibm.ws.jndi.iiop_1.0.14.jar=81ee1f5b336136fe97a5b08f7169f95a
lib/features/com.ibm.websphere.appserver.jndi1.0-iiop1.0.mf=0488294c623709674cdd270f268ffd9e
