#Tue Nov 01 14:38:22 IST 2016
dev/api/spec/com.ibm.ws.javaee.persistence.2.0_1.0.14.jar=eadf02b53f490db386fb9f3b873168d9
lib/features/com.ibm.websphere.appserver.javax.persistence-2.0.mf=067eb7ed12fa9d042e6992386e4cf0bb
