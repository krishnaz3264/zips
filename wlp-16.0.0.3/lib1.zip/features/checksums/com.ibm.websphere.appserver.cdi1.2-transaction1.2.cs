#Wed Aug 31 18:57:16 BST 2016
lib/com.ibm.ws.cdi-1.2.transaction_1.0.14.jar=f966e7d060014d2f179047559ad80174
lib/features/com.ibm.websphere.appserver.cdi1.2-transaction1.2.mf=fbf24a2d21179ac78b7e956200d43b4e
