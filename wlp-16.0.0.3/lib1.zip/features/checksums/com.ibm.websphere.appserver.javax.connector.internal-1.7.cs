#Wed Aug 31 18:57:16 BST 2016
dev/api/spec/com.ibm.ws.javaee.connector.1.7_1.0.14.jar=2b3aa8d0f4bee32f9624d75913b613cf
lib/features/com.ibm.websphere.appserver.javax.connector.internal-1.7.mf=31fca030fe2a459a1578175f47f6da8d
