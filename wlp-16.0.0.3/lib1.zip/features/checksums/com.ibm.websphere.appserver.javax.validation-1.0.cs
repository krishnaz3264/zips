#Tue Nov 01 14:33:51 IST 2016
dev/api/spec/com.ibm.ws.javaee.validation.1.0_1.0.14.jar=7d4246daf665595cb8e0b078f527f316
lib/features/com.ibm.websphere.appserver.javax.validation-1.0.mf=5074ef42e8762dc7fc475f407a106b54
