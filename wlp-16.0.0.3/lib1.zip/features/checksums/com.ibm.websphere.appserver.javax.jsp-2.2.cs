#Tue Nov 01 14:30:44 IST 2016
lib/features/com.ibm.websphere.appserver.javax.jsp-2.2.mf=a693b87c002d0282fd2d3a3add89ae73
dev/api/spec/com.ibm.ws.javaee.jsp.2.2_1.0.14.jar=3f9c16288d08b5d0f3de706861777a0f
