#Wed Aug 31 18:57:15 BST 2016
lib/features/com.ibm.websphere.appserver.javax.interceptor-1.1.mf=b8a0803ea3a373d15f4f82c74e5e5317
dev/api/spec/com.ibm.ws.javaee.interceptor.1.1_1.0.14.jar=8c950e91dbb56a92b911750c1a27b2bf
