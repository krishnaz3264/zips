#Wed Aug 31 18:57:16 BST 2016
lib/features/com.ibm.websphere.appserver.jaxrsClient-2.0.mf=5c03276f386c72f7565e1c47a8cdaa71
lib/com.ibm.ws.jaxrs-2.0.client_1.0.14.jar=ca49c304effcc72c3b0dcb5b24d81401
