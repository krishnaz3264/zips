#Tue Nov 01 14:48:47 IST 2016
lib/features/com.ibm.websphere.appserver.internal.jca-1.6.mf=e2e5b363879357c6769285a91bc6397e
lib/com.ibm.ws.jca.utils_1.0.14.jar=571e45924abdb254bba4091bac0c68f3
lib/com.ibm.ws.jca.feature_1.0.14.jar=08b40be7cea5d270acaf9910211f419f
lib/com.ibm.ws.jca_1.0.14.jar=1863c073ad3b0ce8b843213f1dbec358
