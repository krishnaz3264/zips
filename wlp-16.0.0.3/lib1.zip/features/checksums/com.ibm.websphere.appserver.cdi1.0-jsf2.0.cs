#Tue Nov 01 14:39:36 IST 2016
lib/features/com.ibm.websphere.appserver.cdi1.0-jsf2.0.mf=2d45250f46c8ddcaa5092fd99ca7b035
lib/com.ibm.ws.openwebbeans-jsf.1.1.6_1.0.14.jar=dd1d01d05202230b34fe44a05134d8ea
