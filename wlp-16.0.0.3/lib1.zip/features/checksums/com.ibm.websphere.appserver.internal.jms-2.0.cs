#Tue Nov 01 15:12:33 IST 2016
dev/api/spec/com.ibm.ws.javaee.jms.2.0_1.0.14.jar=524c4a228e7696c1f30267fc5773bb62
lib/features/com.ibm.websphere.appserver.internal.jms-2.0.mf=de940fdba569a8c9002cbae1414ef78a
lib/com.ibm.ws.messaging.jmsspec.common_1.0.14.jar=f20c2f7b3c9a80947609efc609c179ef
