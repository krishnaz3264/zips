#Sat Feb 27 17:09:05 GMT 2016
dev/api/spec/com.ibm.ws.javaee.interceptor.1.2_1.0.12.jar=30146df95f6c9c35aa92468587f753e0
lib/features/javax.interceptor-1.2.mf=fa4cf99ccd46d900ac3cae196963b9e6
