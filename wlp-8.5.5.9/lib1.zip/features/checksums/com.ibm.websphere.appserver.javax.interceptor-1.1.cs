#Sat Feb 27 17:09:05 GMT 2016
dev/api/spec/com.ibm.ws.javaee.interceptor.1.1_1.0.12.jar=3c8b2ddc4378e5de1db60386b9f12c3c
lib/features/javax.interceptor-1.1.mf=8bcd4ff4d0dec1f7b8eff7e1bf4a723d
