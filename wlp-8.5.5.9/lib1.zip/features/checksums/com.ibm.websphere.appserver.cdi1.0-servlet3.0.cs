#Thu Sep 15 10:41:54 IST 2016
lib/features/cdi1.0-servlet3.0.mf=fc1838cc263d4643229e9eb551b87a0f
lib/com.ibm.ws.openwebbeans-web.1.1.6_1.0.12.jar=3fab90304a2efbf4339523b7eeb50b2a
lib/com.ibm.ws.openwebbeans-ee-common.1.1.6_1.0.12.jar=db8195cc97f91e4b91fc4a5ebdb03d66
