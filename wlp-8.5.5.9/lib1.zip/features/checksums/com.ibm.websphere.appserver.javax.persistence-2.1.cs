#Sat Feb 27 17:09:04 GMT 2016
lib/com.ibm.ws.javaee.persistence.api.2.1_1.0.12.jar=34566b35035c8d62ec2d0af0dd8d4ddb
lib/features/javax.persistence-2.1.mf=fa578efcea50990e35c441d7de860ea2
dev/api/spec/com.ibm.ws.javaee.persistence.dev.2.1_1.0.12.jar=c6f70590bcb4dd6a7ca86307071b5b4a
