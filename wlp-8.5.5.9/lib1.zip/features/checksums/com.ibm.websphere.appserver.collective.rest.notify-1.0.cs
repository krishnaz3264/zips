#Mon Oct 31 17:50:12 IST 2016
lib/com.ibm.ws.collective.rest.notify_1.0.12.jar=d0905fb0ecbebed75c0c5c0b6eba1a63
lib/com.ibm.ws.joda-time.1.6.2_1.0.12.jar=63b5cf2785929ac535767ee7546700bc
lib/features/collective.rest.notify-1.0.mf=e21c26a591ebb0c4df5f1efc42ef307c
