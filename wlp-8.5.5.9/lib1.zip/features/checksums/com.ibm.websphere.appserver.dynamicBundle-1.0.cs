#Sat Feb 27 17:09:04 GMT 2016
lib/com.ibm.ws.dynamic.bundle_1.0.12.jar=20e3b5561f8828a2340f2d493cc2e1b4
lib/features/dynamicBundle-1.0.mf=1e16d47b7b760af3ccefbe1257728d3a
