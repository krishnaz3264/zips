#Wed Jun 15 10:02:13 IST 2016
lib/com.ibm.ws.webservices.javaee.common_1.0.12.jar=ad584280c8d424dc56870b342ed84b77
dev/api/spec/com.ibm.ws.javaee.jaxws.2.2_1.0.12.jar=af827b447ff595d09cd64071b5d894be
lib/com.ibm.ws.javaee.ddmodel.ws_1.0.12.jar=935b33186611be28279f83384a40fe54
lib/features/webservicesee-1.3.mf=619b281dfbbf28a960ff0ec5896c169b
