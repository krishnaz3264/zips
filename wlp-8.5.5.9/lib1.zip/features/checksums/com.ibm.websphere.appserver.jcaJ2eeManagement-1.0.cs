#Thu Sep 15 11:03:08 IST 2016
lib/features/jcaJ2eeManagement-1.0.mf=13ad5d2b724fe30d033b26a72d372315
lib/com.ibm.ws.jca.management.j2ee_1.0.12.jar=3bcb322fa2ff5b3f6d13faf1e0aced9b
