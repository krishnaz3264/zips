#Tue Aug 30 00:54:01 IST 2016
dev/api/spec/com.ibm.ws.javaee.jsp.2.2_1.0.12.jar=c1cddb4c7a0591cad07eb42a95ca3676
lib/features/javax.jsp-2.2.mf=ae065f53fd387ca70c5cc897fd9d5245
