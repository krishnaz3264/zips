#Tue Aug 30 01:08:26 IST 2016
lib/com.ibm.ws.jpa.container.beanvalidation_1.0.12.jar=fa75863c7dbac96326a85958c4af4cec
lib/features/jpa2.0-bv1.0.mf=a163d7585a7e6651b0f3f575eeb52e90
