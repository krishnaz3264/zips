#Wed Jun 15 10:05:34 IST 2016
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.json_1.0-javadoc.zip=58cb87efbbb282c9367053f9672c1821
dev/api/ibm/com.ibm.websphere.appserver.api.json_1.0.12.jar=536fa5e2eca74604d2261c7201e49955
lib/features/json-1.0.mf=49774b4c2bd7d80927252d300ef98d38
lib/com.ibm.json4j_1.0.12.jar=ac14fd62042a5831004de1c4c794316d
