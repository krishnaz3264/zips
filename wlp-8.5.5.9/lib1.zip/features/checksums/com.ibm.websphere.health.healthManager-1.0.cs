#Mon Oct 31 18:22:50 IST 2016
lib/com.ibm.ws.dynamic.routing.share_1.0.12.jar=05386bc78b46a7f74e224bc7a028d07c
lib/com.ibm.ws.health.manager_1.0.12.jar=b4a6f32cca587e166c13482c90d799f8
lib/features/healthManager-1.0.mf=2be00f9c872cb6caff7a9e06edcba7c1
