#Thu Sep 15 11:03:08 IST 2016
lib/com.ibm.ws.jbatch.cdi_1.0.12.jar=0c4185a5738dff6556567be9866b643f
lib/features/cdi-1.2-batch-1.0.mf=05bd1ab6afcaddb36e9d20ccd5700415
