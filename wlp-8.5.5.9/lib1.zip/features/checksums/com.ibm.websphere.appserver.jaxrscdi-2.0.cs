#Wed Jun 15 10:05:42 IST 2016
lib/features/jaxrscdi-2.0.mf=d6db84bd7f7ba0a29c6dfba1a09bafc0
lib/com.ibm.ws.jaxrs-2.0.cdi_1.0.12.jar=4a276e474692544f637a7ee0a13a152c
