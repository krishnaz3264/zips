#Thu Sep 15 11:03:15 IST 2016
lib/com.ibm.ws.app.management.j2ee_1.0.12.jar=dd452abcf490633b7a33e437ac078021
lib/features/appJ2eeManagement-1.0.mf=ac21307e6be9a2488e70f02da17bbdff
