#Sat Feb 27 17:09:05 GMT 2016
dev/api/ibm/schema/ibm-managed-bean-bnd_1_0.xsd=914d243e72b5fdf8dfbff4f6be3e4bc9
lib/com.ibm.ws.managedbeans_1.0.12.jar=724bb5e839a817ff465355a4a64de723
dev/api/ibm/schema/ibm-managed-bean-bnd_1_1.xsd=d90f6abac37958438d8018aa10797eee
lib/features/com.ibm.websphere.appserver.managedBeans-1.0.mf=5a6e426cb525af0ab22de7b1e873ce99
