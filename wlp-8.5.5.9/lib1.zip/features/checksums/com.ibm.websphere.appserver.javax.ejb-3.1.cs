#Sat Feb 27 17:09:04 GMT 2016
dev/api/spec/com.ibm.ws.javaee.ejb.3.1_1.0.12.jar=c9a8a955100bb568811caed58134ed41
lib/features/javax.ejb-3.1.mf=35db192ef5cba91cd04ada128925a396
