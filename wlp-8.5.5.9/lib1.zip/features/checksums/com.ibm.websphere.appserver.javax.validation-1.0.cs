#Tue Aug 30 00:57:57 IST 2016
dev/api/spec/com.ibm.ws.javaee.validation.1.0_1.0.12.jar=e45cc6d1e5ddc7666207777f9d223bbf
lib/features/javax.validation-1.0.mf=0ae0f0fd74ab45d06ef3dde648d8cc90
