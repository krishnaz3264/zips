#Tue Aug 30 01:08:24 IST 2016
dev/api/third-party/com.ibm.ws.jpa_1.2.12.jar=58ec4037381139cc7926a2f5d07573be
lib/features/jpaApiStub-2.0.mf=a29d82e8d7ccb0b8937465641a54c1a5
