#Thu Sep 15 10:56:00 IST 2016
lib/com.ibm.ws.ejbcontainer.mdb_1.0.12.jar=f575eaad51489bef48129c122ce143a4
lib/features/jmsMdb-3.1.mf=f336d9347c464c8786637cf118dfce62
