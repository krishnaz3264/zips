#Tue Nov 01 14:21:58 IST 2016
lib/com.ibm.ws.scaling.common_1.0.12.jar=b0ee6bbcb0f4d5a706c7b636a2895353
dev/api/ibm/com.ibm.websphere.appserver.api.scalingMember_1.0.12.jar=eb2d3f32d6da74c7cb2bfaf92e3681af
lib/com.ibm.websphere.collective.singleton_1.0.12.jar=756ffa0dff3241791f0890676332b52f
lib/features/scalingMember-1.0.mf=65d867f8cf4857d0b8bbc96ee435557c
lib/com.ibm.ws.scaling.member_1.0.12.jar=165482b693733dd0ad932653f49ad5fe
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.scalingMember_1.0-javadoc.zip=418f3634099c98e58d62d54472625950
