#Sat Feb 27 17:09:04 GMT 2016
lib/com.ibm.ws.jpa.container.v21.cdi_1.0.12.jar=1cd40151abf361013fd64e1e3263ba3e
lib/features/jpa2.1-cdi1.2.mf=a4ee4317c783f76b0fec9cf8f096de99
