#Tue Aug 30 00:57:57 IST 2016
lib/features/javax.persistence-2.0.mf=a029788e45207c4a4e80dbeae78f3529
dev/api/spec/com.ibm.ws.javaee.persistence.2.0_1.0.12.jar=ebcd05e47de40780d9659d31b11689bc
