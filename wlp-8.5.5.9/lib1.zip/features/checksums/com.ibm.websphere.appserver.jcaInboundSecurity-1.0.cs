#Thu Sep 15 11:03:13 IST 2016
lib/com.ibm.ws.jca.inbound.security_1.0.12.jar=0496c63ae6021a6e36ab113c47ea2c69
dev/api/spec/com.ibm.ws.javaee.jaspic.1.1_1.0.12.jar=913914585c89a0fc1db201072e2f2dfe
lib/features/jcaInboundSecurity-1.0.mf=956297aa92c1933e8d2ab2954ac354c4
