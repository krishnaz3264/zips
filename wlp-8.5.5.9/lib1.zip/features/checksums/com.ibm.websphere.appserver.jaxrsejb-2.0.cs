#Wed Jun 15 10:52:09 IST 2016
lib/com.ibm.ws.jaxrs-2.0.ejb_1.0.12.jar=0aba1da3996d02f9236e0f573943a540
lib/features/jaxrsejb-2.0.mf=fa07dedc8dfc405c2cc8716693662d24
