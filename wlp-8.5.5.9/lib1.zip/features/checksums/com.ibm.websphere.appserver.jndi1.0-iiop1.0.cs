#Sat Feb 27 17:09:04 GMT 2016
lib/com.ibm.ws.jndi.iiop_1.0.12.jar=4d761451a9577ef50c5b61a54d9c6330
lib/features/com.ibm.websphere.appserver.jndi1.0-iiop1.0.mf=647d1cbf555b8583caf2c12ac6ebf423
