#Wed Jun 15 10:52:09 IST 2016
lib/features/jaxrsEJB-1.1.mf=9ef47bcdd8851358ed31b95408505d04
lib/com.ibm.ws.jaxrs.ejb_1.0.12.jar=7d97a866f6dfe21616c022eba06cd031
