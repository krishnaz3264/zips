#Wed Jun 15 10:05:33 IST 2016
dev/spi/ibm/com.ibm.websphere.appserver.spi.httptransport_1.1.12.jar=f58d4b29558df285cb5d62fbe5c356b8
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.httptransport_1.1-javadoc.zip=8351d7ee47b7d9eee2fb4541cf93a07a
lib/com.ibm.ws.transport.http_1.0.12.jar=ac689663ed34590ebe3afa92b9e7dced
lib/features/httptransport-1.0.mf=6cb7ccd0bbbc49dfdaf7176f25132e92
lib/com.ibm.ws.javaee.version_1.0.12.jar=213e21405c201c22e30b836efb6f6265
