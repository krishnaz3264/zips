#Sat Feb 27 17:09:04 GMT 2016
lib/com.ibm.ws.jca.resourcedefinition.jms-2.0_1.0.12.jar=143b21f98bd102f7f9ee23532d9a63bb
lib/features/resourcedefinition.jms-2.0.mf=63b25c9e916f1927e29324883ef3104e
