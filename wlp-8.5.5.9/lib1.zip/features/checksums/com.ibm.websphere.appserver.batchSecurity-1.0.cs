#Thu Sep 15 11:03:09 IST 2016
lib/com.ibm.ws.jbatch.security_1.0.12.jar=b21d4c6157ad3098698bfa2a23581c73
lib/features/batchSecurity-1.0.mf=c495a60696fca279ee186a97b9549a67
