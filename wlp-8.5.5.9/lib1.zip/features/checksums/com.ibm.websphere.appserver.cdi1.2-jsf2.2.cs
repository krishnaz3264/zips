#Tue Aug 30 00:59:35 IST 2016
lib/features/cdi1.2-jsf2.2.mf=b668a01c9bb8939b05e3360e0b3a81ea
lib/com.ibm.ws.cdi-1.2.jsf_1.0.12.jar=812da9ff8bb194972ed9208f958cc166
