#Sat Feb 27 17:09:05 GMT 2016
dev/api/spec/com.ibm.ws.javaee.ejb.3.2_1.0.12.jar=0b67d59f886cf4339dee8d67b3efadd0
lib/features/javax.ejb-3.2.mf=4749e80b5e83bd32336119e779468e5c
