#Thu Sep 15 11:03:16 IST 2016
lib/com.ibm.ws.jndi.management.j2ee_1.0.12.jar=b130b17aba9e5000bd33c307c304ead7
lib/features/jndiJ2eeManagement-1.0.mf=6cf6cc81418fcf25f87468c6298dc2c3
