#Wed Jun 15 10:02:13 IST 2016
lib/com.ibm.ws.jaxws.cdi_1.0.12.jar=14fbb8e1796c4590be340d77bf9de210
lib/features/jaxwscdi-2.2.mf=c5f343acdf1160a7ca1673cca3bec4eb
