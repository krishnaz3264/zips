#Sat Feb 27 17:09:05 GMT 2016
lib/com.ibm.ws.cdi-1.2.weld.impl_1.0.12.jar=e297599fc5a696bdce04f87c7c998e51
dev/api/spec/com.ibm.ws.javaee.jstl.1.2_1.0.12.jar=bbbdbf7b8f3ee30d4dba51d428ad946c
lib/com.ibm.ws.weld-osgi-bundle.2.2.16_1.0.12.jar=3f32030014c3a6bba68a0bbccecfdc5f
lib/com.ibm.ws.cdi-1.2.runtime.extension_1.0.12.jar=39ce5fc730c81c98e49264c046b2c95d
lib/features/com.ibm.websphere.appserver.cdi-1.2.mf=ddee61e5808e9cb49faa31ac0cd2efe1
lib/com.ibm.ws.managedobject_1.0.12.jar=5502ea5d595a24f518d1b88dbd93d4ca
lib/com.ibm.ws.jboss-logging.3.1.3_1.0.12.jar=21dc278c37e806d10f81bee7d75d309e
dev/api/ibm/schema/ibm-managed-bean-bnd_1_1.xsd=d90f6abac37958438d8018aa10797eee
dev/api/spec/com.ibm.ws.javaee.jsf.2.2_1.0.12.jar=9b7587b7a180d4e97745e36d5c9a292f
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.cdi_1.0.12.jar=f06e456be4a45e16aeaeefacdf3784ea
lib/com.ibm.ws.jdeparser.1.0.0_1.0.12.jar=a0a4a71709ff167f32797785162fd2c7
dev/api/ibm/schema/ibm-managed-bean-bnd_1_0.xsd=914d243e72b5fdf8dfbff4f6be3e4bc9
lib/com.ibm.ws.guava.14.0.1_1.0.12.jar=0b5706b3fbb1b679770217b5de2dc922
