#Thu Sep 15 11:00:15 IST 2016
lib/com.ibm.ws.messaging.jms.wmq_1.0.12.jar=ed739a3fd9fb0f7c8fa40f7dff493da7
lib/features/wmqJmsClient-2.0.mf=a3c9611b5cb28de04c50833174d06328
