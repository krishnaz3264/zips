#Wed Jun 15 11:05:14 IST 2016
lib/com.ibm.ws.app.manager.rar_1.0.12.jar=ca7fc4e71e1a0674962a2f914f400069
lib/features/jca-1.6.mf=3cfd77213aefeb28d753c8752ac47f38
