#Sat Feb 27 17:09:04 GMT 2016
lib/com.ibm.ws.cdi-1.2.transaction_1.0.12.jar=e02287fe49fc6262b00628dac4969ad8
lib/features/cdi1.2-transaction1.2.mf=8949196fd17cc6fa943ba745173283f3
