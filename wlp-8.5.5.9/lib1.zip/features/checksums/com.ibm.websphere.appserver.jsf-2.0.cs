#Tue Aug 30 00:57:58 IST 2016
dev/api/spec/com.ibm.ws.javaee.jsf.tld.2.0_1.1.12.jar=15d3f58d5f2b50a2fe8dfa45bb84eaa7
lib/com.ibm.ws.org.apache.commons.logging.1.0.3_1.0.12.jar=8439b96f56aab7163ac8d5e35d2f9a7e
lib/com.ibm.ws.jsf_1.0.12.jar=dd7e393a6b8b8fd473d81d2345417d50
dev/api/spec/com.ibm.ws.javaee.jsf.2.0_1.0.12.jar=24321aed19de8c5994ef0bfa22bab55a
lib/com.ibm.ws.org.apache.commons.discovery.0.2_1.0.12.jar=b42ef77bc0fb3022f532663ca46345ab
dev/api/spec/com.ibm.ws.javaee.jstl.1.2_1.0.12.jar=bbbdbf7b8f3ee30d4dba51d428ad946c
lib/com.ibm.ws.org.apache.commons.collections.3.2.1_1.0.12.jar=3c2f887a6b74113988bd5c1eef180cd8
lib/features/jsf-2.0.mf=f2acc02eb12addfaaa15f41fa9d5c7d7
