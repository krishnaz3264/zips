#Wed Jun 15 10:05:38 IST 2016
lib/com.ibm.ws.jaxrs-2.0.server_1.0.12.jar=8a41f32e62b28d9caf01f99f28e25d84
lib/features/jaxrs-2.0.mf=01d2cce5a937cd646e5691b8bc985af6
lib/com.ibm.ws.jaxrs-2.0.web_1.0.12.jar=610dc4d9998873a3fc5758ef7009649a
