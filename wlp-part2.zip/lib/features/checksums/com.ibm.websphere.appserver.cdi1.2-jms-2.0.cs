#Sat Feb 27 17:09:04 GMT 2016
lib/com.ibm.ws.cdi-1.2.jms_1.0.12.jar=cbef57d5c7c3683101819e30b9baa8f5
lib/features/cdi1.2-jms2.0.mf=cc5afb7ef2bc0165b92f1350f5f3af05
