#Wed Jun 15 10:02:09 IST 2016
lib/com.ibm.webservices.handler_1.0.12.jar=17e57a47fc7f5be4475a9c4e3c438c73
lib/features/globalWebservicesHandler-1.0.mf=12e68f24ed377b60a9773ec5e300e5d9
dev/spi/ibm/com.ibm.websphere.appserver.spi.globalhandler_1.0.12.jar=97bd475f85d94a254cd1ce46bcc3b9da
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.globalhandler_1.0-javadoc.zip=b4dc10f402d5b96bcadfcffc4eac3192
