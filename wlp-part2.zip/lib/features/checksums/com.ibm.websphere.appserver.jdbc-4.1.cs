#Sat Feb 27 17:09:05 GMT 2016
lib/com.ibm.ws.jdbc_1.0.12.jar=7867bdc9e583574925bc06849643882a
lib/com.ibm.ws.jdbc41_1.0.12.jar=3cbea931d9b82c22c423c2e83e06a9ec
lib/features/com.ibm.websphere.appserver.jdbc-4.1.mf=60d1488091d6cb8891a1b125a872df5e
