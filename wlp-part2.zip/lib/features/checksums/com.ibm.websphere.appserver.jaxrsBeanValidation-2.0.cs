#Wed Jun 15 10:05:43 IST 2016
lib/features/jaxrsBeanValidation-2.0.mf=2257238a6e950e2d098bea421b27bdc1
lib/com.ibm.ws.jaxrs-2.0.beanValidation_1.0.12.jar=e74dcb0cfe73f8f7a18b1827bd3836c8
