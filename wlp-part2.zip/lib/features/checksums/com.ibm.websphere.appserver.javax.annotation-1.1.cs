#Sat Feb 27 17:09:04 GMT 2016
dev/api/spec/com.ibm.ws.javaee.annotation.1.1_1.0.12.jar=6b6b50092fa368af72e14f361de68c79
lib/features/javax.annotation-1.1.mf=f37e3bae3e10762748c28dc74603fbea
