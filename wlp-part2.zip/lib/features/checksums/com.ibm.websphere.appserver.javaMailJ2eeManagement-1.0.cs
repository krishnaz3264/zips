#Thu Sep 15 11:03:10 IST 2016
lib/features/javaMailJ2eeManagement-1.0.mf=477fc443e0da2705709dd58cee6bd16c
lib/com.ibm.ws.javamail.management.j2ee_1.0.12.jar=4b39fff99abc69b860c0e342c12365dd
