#Thu Sep 15 10:56:40 IST 2016
lib/features/jmsMdb-3.2.mf=eaee5b2f23524a20edfcf933bd8496cd
lib/com.ibm.ws.ejbcontainer.mdb_1.0.12.jar=f575eaad51489bef48129c122ce143a4
