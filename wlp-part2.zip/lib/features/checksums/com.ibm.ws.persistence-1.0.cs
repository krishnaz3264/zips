#Thu Sep 15 10:53:52 IST 2016
dev/api/ibm/com.ibm.websphere.appserver.api.persistence_1.0.12.jar=615b828c4fafb229e1eb1c5d70c86426
bin/tools/ws-generateddlutil.jar=a7499b8a7a02b6e483c6841b9ffa15a2
lib/com.ibm.ws.persistence_1.0.12.jar=07bd68959959c02885e50ff85d3c3133
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.persistence_1.0-javadoc.zip=3138d9174266f41737963d7393bd1460
lib/features/persistence-1.0.mf=c7fac88056493d22d5ac9230336aba31
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.eclipselink_1.0.12.jar=19de6c80163772853f515ed884d40786
lib/com.ibm.ws.persistence.mbean_1.0.12.jar=2f05190baec505b468418e738664137d
lib/com.ibm.ws.persistence.utility_1.0.12.jar=fd0d6ed628f31dcf4d0c22e124b83489
