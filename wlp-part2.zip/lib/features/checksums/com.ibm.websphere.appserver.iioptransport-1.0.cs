#Thu Sep 15 10:53:48 IST 2016
lib/features/iioptransport-1.0.mf=da0ab3c4a45ef2f4ce00747179a44442
lib/com.ibm.ws.transport.iiop.server_1.0.12.jar=de979508569f78377d89ed8408ebe3a5
