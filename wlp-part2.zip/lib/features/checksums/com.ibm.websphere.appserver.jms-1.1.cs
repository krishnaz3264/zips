#Wed Jun 15 11:05:15 IST 2016
lib/com.ibm.ws.jms.feature_1.0.12.jar=d9a535e872b552d31615cb9dd4027933
lib/features/jms-1.1.mf=31b8958ca5894b5e86614b7f347c7558
