#Sat Feb 27 17:09:04 GMT 2016
lib/com.ibm.ws.javaee.persistence.2.1_1.0.12.jar=17790cc3e6cffc40ccc18b0f6825bd8a
lib/features/javax.persistence.base-2.1.mf=9a3148ae3111b5e09d0879dda6438d54
