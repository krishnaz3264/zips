#Wed Jun 15 10:05:42 IST 2016
lib/com.ibm.ws.jaxws.web_1.0.12.jar=a4a7f715cea13242727a3d2403718e3a
lib/features/jaxwsweb-2.2.mf=10af026379b776d99d77b577ff7d2b4f
lib/com.ibm.ws.jaxws.webcontainer_1.0.12.jar=4648b859f0cc2818def0fd9d79bdb031
