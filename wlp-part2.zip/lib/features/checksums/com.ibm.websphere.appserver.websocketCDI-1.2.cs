#Thu Sep 15 10:49:07 IST 2016
lib/com.ibm.ws.wsoc.cdi.weld_1.0.12.jar=e1fca461bcfbc3b2f71ce1c0e4c7432f
lib/features/websocketCDI-1.2.mf=5631480ace361f828a232ad9c92caeac
