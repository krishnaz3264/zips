#Sat Feb 27 17:09:04 GMT 2016
dev/api/spec/com.ibm.ws.javaee.servlet.3.1_1.0.12.jar=3ae6903e33514af79bfe4a828d88da04
lib/features/javax.servlet-3.1.mf=55f9db7928f1e353ea47e052449c5810
