#Wed Jun 15 10:05:38 IST 2016
lib/com.ibm.ws.jaxrs-2.0.client_1.0.12.jar=0c87d8c3afd8fbae834edd70c2bbed15
lib/features/jaxrsClient-2.0.mf=8718a8694367260588ce980738f73a0a
