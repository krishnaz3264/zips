#Sat Feb 27 17:09:04 GMT 2016
lib/com.ibm.ws.javaee.platform.v7.jndi_1.0.12.jar=66bc12f25a2abd5bfbf8df7bba7491c1
lib/features/javaeePlatform7.0-jndi1.0.mf=d076a517b8bf6787fc4d02c41bbec42a
