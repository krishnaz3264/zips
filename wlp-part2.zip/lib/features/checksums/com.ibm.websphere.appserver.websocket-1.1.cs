#Thu Sep 15 10:49:07 IST 2016
lib/features/websocket-1.1.mf=3b7a5c248641140e27f86c545bb539a8
dev/api/spec/com.ibm.ws.javaee.websocket.1.1_1.0.12.jar=0d51a2665fbb47da6de2581890121da5
dev/api/ibm/com.ibm.websphere.appserver.api.wsoc_1.0.12.jar=18f9a862752b7a0094ac2538912254bb
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.wsoc_1.0-javadoc.zip=c78f9a598538632a862400a610eacabf
lib/com.ibm.ws.wsoc_1.0.12.jar=ab151019497a7086d6dca4ba4b0a9c16
lib/com.ibm.ws.wsoc11_1.0.12.jar=9f96122c53a157f1ba30de81b64c70b4
