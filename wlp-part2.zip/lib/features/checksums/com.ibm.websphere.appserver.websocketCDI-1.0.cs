#Thu Sep 15 10:49:07 IST 2016
lib/features/websocketCDI-1.0.mf=868b98d93ab3c9cfab368eec54303cbf
lib/com.ibm.ws.wsoc.cdi_1.0.12.jar=5a352c3aea05ffcd0fe4c96f704ff630
