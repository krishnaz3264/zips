#Wed Jun 15 10:05:37 IST 2016
dev/api/ibm/com.ibm.websphere.appserver.api.jaxrs20_1.0.12.jar=c2a9aeb1af890acbde7992114dbe31f3
lib/com.ibm.ws.org.apache.neethi.3.0.2_1.0.12.jar=81ff07cafde448a84cc1162fd8b7e0df
lib/features/jaxrscommon-2.0.mf=0c452dfaf1ed3e52cadf82e980e2487f
lib/com.ibm.ws.jaxrs-2.0.tools_1.0.12.jar=cee3f12afe5d70fce9ba2e2f73013c6f
lib/com.ibm.ws.jaxrs-2.0.common_1.0.12.jar=799dbd475248fc8d2003193875f3c82a
dev/api/spec/com.ibm.ws.javaee.jaxrs.2.0_1.0.12.jar=fe7cbd69b7ece62011253785bc3f8f85
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.jaxrs20_1.0-javadoc.zip=04df032633024c48d924e0201fd691bb
lib/com.ibm.ws.org.apache.xml-resolver.1.2_1.0.12.jar=9e64f6ad22c939c70890a0f1369621ef
bin/jaxrs/tools/wadl2java.jar=8d8abb6f078d54cc0c9f6c3197efb671
lib/com.ibm.ws.org.apache.ws.xmlschema.core.2.0.3_1.0.12.jar=3149cf2bb24a1fcf9c1d6119fc8b1e44
