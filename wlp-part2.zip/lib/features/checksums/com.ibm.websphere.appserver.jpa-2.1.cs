#Sat Feb 27 17:09:04 GMT 2016
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.eclipselink.2.6.1_WAS_1.0.12.jar=19de6c80163772853f515ed884d40786
lib/com.ibm.ws.jpa.container_1.0.12.jar=87a0782088243789398d9e79284dfa14
lib/com.ibm.ws.jpa.container.v21_1.0.12.jar=44130f1aa3411130cf74eb141b92ec10
lib/com.ibm.ws.jpa.container.eclipselink_1.0.12.jar=d0de1898f83d3a3412bf34d7d55c76b1
lib/features/com.ibm.websphere.appserver.jpa-2.1.mf=ad23beef37ce93e78d1292a4a000b4c9
