#Sat Feb 27 17:09:04 GMT 2016
lib/com.ibm.ws.transaction.cdi_1.0.12.jar=c1bd326941decfa4df2c242ee7d46824
lib/com.ibm.tx.util_1.0.12.jar=bb1438fd6567b61d1bc44e5a3a7081f5
lib/com.ibm.ws.tx.jta.extensions_1.0.12.jar=6baf6e6c71218ac4db664be2dead6cad
lib/com.ibm.ws.cdi-1.2.runtime.extension_1.0.12.jar=39ce5fc730c81c98e49264c046b2c95d
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.transaction_1.1-javadoc.zip=8720df5095714a114cad6c88c6ab2ab9
lib/com.ibm.ws.recoverylog_1.0.12.jar=426060ec553c0cd52fddba8951c906b1
lib/com.ibm.rls.jdbc_1.0.12.jar=9b57586fa471ebaf50fb3f05adaa5829
dev/spi/ibm/com.ibm.websphere.appserver.spi.transaction_1.1.12.jar=3a25eeaa8ebcda608609a67bef0e3954
lib/com.ibm.ws.transaction_1.0.12.jar=64348fe0b28b412d9009183b3d43c3e9
lib/com.ibm.tx.jta_1.0.12.jar=475b87f07c8de641062a94c7020bfab1
lib/features/transaction-1.2.mf=316dbad73137e138b44700f6b127fe63
lib/com.ibm.ws.tx.embeddable_1.0.12.jar=f4124242f0b64e55919a93c23acb112a
lib/com.ibm.tx.ltc_1.0.12.jar=e7885fce50aed28861e76a3e687f19c3
