#Thu Sep 15 11:03:14 IST 2016
lib/com.ibm.ws.security.jaspic-1.1_1.0.12.jar=6bccbb029d1b9c6315f0897a4dfeb75c
dev/api/spec/com.ibm.ws.javaee.jaspic.1.1_1.0.12.jar=913914585c89a0fc1db201072e2f2dfe
lib/features/jaspic-1.1.mf=765a88693e0aca0c9f36f22139530774
