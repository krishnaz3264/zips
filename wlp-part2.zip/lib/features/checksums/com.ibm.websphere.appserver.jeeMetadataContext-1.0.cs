#Sat Feb 27 17:09:05 GMT 2016
lib/com.ibm.ws.javaee.metadata.context_1.0.12.jar=3e9aa14767461ae2c3572c599f3f7bc5
lib/features/jeeMetadataContext-1.0.mf=df21ce9ae55364735097298bba7114f3
