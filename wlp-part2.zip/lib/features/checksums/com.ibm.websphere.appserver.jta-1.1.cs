#Sat Feb 27 17:09:05 GMT 2016
dev/api/spec/com.ibm.ws.javaee.transaction.1.1_1.0.12.jar=2a8217e0a2da9c1ede58a5119eab2b01
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.12.jar=3b78d9770655c18d956dd98c09d0a173
lib/features/jta-1.1.mf=9d329c53b76790786c80ac406bf94b54
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=f02b43363895d799b104355320618d3d
