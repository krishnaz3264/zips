#Sat Feb 27 17:09:04 GMT 2016
lib/features/javax.jsp-2.3.mf=a1dd60e4410d04b553e7d3d569cdd5b2
dev/api/spec/com.ibm.ws.javaee.jsp.2.3_1.0.12.jar=5fca23779b404f20501263cce46f4287
