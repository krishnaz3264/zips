#Sat Feb 27 17:09:04 GMT 2016
lib/features/javaeePlatform-7.0.mf=9f12eccf7664206614e78bae7ad1867a
lib/com.ibm.ws.javaee.version_1.0.12.jar=213e21405c201c22e30b836efb6f6265
lib/com.ibm.ws.javaee.platform.v7_1.0.12.jar=15550c008edd0fda013434830b810ca5
lib/com.ibm.ws.javaee.platform.defaultresource_1.0.12.jar=50feefa84ebe1d49d8b4ff529c035a67
