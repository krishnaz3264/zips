#Sat Feb 27 17:09:04 GMT 2016
lib/com.ibm.ws.org.glassfish.json.1.0_1.0.12.jar=28d87410cee1a0814f1ca7bf368a3e4b
lib/features/com.ibm.websphere.appserver.jsonp-1.0.mf=be3c1f1616aa97094c03cbd4d840a590
dev/api/spec/com.ibm.ws.javaee.jsonp.1.0_1.0.12.jar=e3adfce5b29368c71cc66b1eb529ae59
