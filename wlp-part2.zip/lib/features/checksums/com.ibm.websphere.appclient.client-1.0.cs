#Sat Feb 27 17:09:05 GMT 2016
bin/tools/ws-client.jar=62e3af0b9081ec7a6511b6e23c88a621
lib/features/com.ibm.websphere.appclient.client-1.0.mf=00ef9afd2b9f7ba7db0a12a2b9aec7f0
lib/com.ibm.ws.appclient.boot_1.0.12.jar=63a67cd00bf50aeb57fe197f49581c54
