#Thu Sep 15 10:59:33 IST 2016
lib/com.ibm.ws.messaging.jms.wmq_1.0.12.jar=ed739a3fd9fb0f7c8fa40f7dff493da7
lib/features/wmqJmsClient-1.1.mf=093e531cea1023644220123a82dec548
