#Sat Feb 27 17:09:05 GMT 2016
lib/features/jndiClient-1.0.mf=d1b9dc398a0efe8ca2b3ea58db101c5c
lib/com.ibm.ws.jndi.remote.client_1.0.12.jar=ba73dc3470ea7a576f46e24957772e56
