#Tue Aug 30 01:08:26 IST 2016
lib/com.ibm.ws.net.sourceforge.serp.1.15.1_1.0.12.jar=27b74066a3305da67cf195091c838587
lib/com.ibm.ws.jpa.container_1.0.12.jar=87a0782088243789398d9e79284dfa14
lib/com.ibm.ws.org.apache.commons.collections.3.2.1_1.0.12.jar=3c2f887a6b74113988bd5c1eef180cd8
lib/features/jpa-2.0.mf=d15ec90cac8d5a11fe7f424e5f3f323c
lib/com.ibm.ws.jpa_1.2.12.jar=df75e21854a8ba8a84b775f0b7789e42
lib/com.ibm.ws.org.apache.commons.pool.1.5.4_1.0.12.jar=3b7d23990e6088a00f9d952d708117ef
lib/com.ibm.ws.org.apache.commons.lang.2.4_1.0.12.jar=6e94a8a33f9c6f2a40198dca328bf36f
lib/com.ibm.ws.jpa.container.wsjpa_1.0.12.jar=1c9290d06ae78e45805a3ecbce584cd9
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.jpa_1.2.12.jar=d1ffbba6f846c91339f0c0bc356b9657
