#Sat Feb 27 17:09:05 GMT 2016
lib/com.ibm.ws.javax.mail-1.5_1.5.12.jar=41fba54253b3448aae41d1f1ad150089
lib/features/javax.mail-1.5.mf=6e0c520a6df365578cfb295738dd3446
