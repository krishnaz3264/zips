#Sat Feb 27 17:09:05 GMT 2016
dev/api/spec/com.ibm.ws.javaee.annotation.1.2_1.0.12.jar=8600e71267dee379e2524ed0e9d72aa3
lib/features/javax.annotation-1.2.mf=3fe02a262c93e91f86ee61aad86ec0a3
