#Thu Sep 15 10:41:54 IST 2016
lib/features/cdi1.0-jndi1.0.mf=5d0ae1ada2d743327c8b4b76657c59d3
lib/com.ibm.ws.openwebbeans-naming.1.1.6_1.0.12.jar=8e36df3e6d57dfb8d44a7750380d969f
