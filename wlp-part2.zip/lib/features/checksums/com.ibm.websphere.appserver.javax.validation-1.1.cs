#Sat Feb 27 17:09:06 GMT 2016
lib/features/javax.validation-1.1.mf=418c9a175084a136b7b309ba4fc7a9a5
dev/api/spec/com.ibm.ws.javaee.validation.1.1_1.0.12.jar=446ba077f13fee17a3f85df324296b14
