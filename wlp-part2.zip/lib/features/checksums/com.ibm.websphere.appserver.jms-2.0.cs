#Wed Jun 15 11:06:55 IST 2016
lib/com.ibm.ws.jms20.feature_1.0.12.jar=c5f3e554a48207af1cb5fd018a45ded1
lib/features/jms-2.0.mf=51478298651dc752046af44e8258904e
