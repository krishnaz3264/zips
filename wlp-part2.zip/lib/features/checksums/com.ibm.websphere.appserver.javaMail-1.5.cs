#Sat Feb 27 17:09:04 GMT 2016
lib/features/com.ibm.websphere.appserver.javaMail-1.5.mf=88b9784e1cdfc149b2ad6eaec660aea5
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.mail_1.0.12.jar=e5d1cf152dc2a8aabb0707b9bcb7abfc
dev/api/spec/com.ibm.ws.javaee.mail.1.5_1.0.12.jar=2405e2911095e879f6ad35d87a9c3bbc
lib/com.ibm.ws.javamail_1.5.12.jar=3698bca7f15ff1b774f9c90e58a2df06
