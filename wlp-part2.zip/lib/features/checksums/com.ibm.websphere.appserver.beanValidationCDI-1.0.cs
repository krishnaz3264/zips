#Sat Feb 27 17:09:05 GMT 2016
lib/com.ibm.ws.beanvalidation.v11.cdi_1.0.12.jar=190187b93210d9e70393c9b6b153acfd
lib/features/beanValidationCDI-1.0.mf=1a5bd3361219f7a4141f8f4d5084a9ac
