#Thu Sep 15 11:03:08 IST 2016
dev/api/spec/com.ibm.ws.javaee.batch.1.0_1.0.12.jar=537df488dce61cf5c7e34fe887f7395b
lib/com.ibm.ws.security.credentials_1.0.12.jar=d513d71e7154a1738bce30a926b86deb
lib/com.ibm.jbatch.container_1.0.12.jar=520a0dad1bef99d49bcd1ea853a1a626
lib/com.ibm.websphere.security_1.0.12.jar=a00cf32cde46e0420f7f106dca4b088c
lib/com.ibm.jbatch.spi_1.0.12.jar=188d8d5990a55a5206d44e99c9f09513
lib/features/batch-1.0.mf=4e5620e1d333002ebd2715e6a30ceb66
