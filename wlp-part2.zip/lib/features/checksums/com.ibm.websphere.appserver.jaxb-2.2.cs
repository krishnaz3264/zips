#Sat Feb 27 17:09:05 GMT 2016
lib/com.ibm.ws.xlxp.1.5.3_1.0.12.jar=0873af7d5aa9146d2e0012031c8eb33b
lib/com.ibm.ws.jaxb.tools.2.2.6_1.0.12.jar=d88cfe51c04972dffe24661e630431fc
lib/com.ibm.ws.org.apache.geronimo.specs.geronimo-osgi-registry.1.1_1.0.12.jar=52cbeb90aee2b6994c52c5ad5477fa68
dev/api/spec/com.ibm.ws.javaee.jaxb.2.2_1.0.12.jar=1ff6c955bc7bc7c7b6accba5c86565c6
lib/features/com.ibm.websphere.appserver.jaxb-2.2.mf=1a95ea5ea8960e51128fb0d08cc39909
bin/jaxb/tools/ws-xjc.jar=8a4123887c93e9dfdede00b2d59d29e4
lib/com.ibm.ws.jaxb.tools.2.2.3_1.0.12.jar=39dd87b9d8ef270d72401e11540409c1
bin/jaxb/tools/ws-schemagen.jar=d37728473073e27f6246c2ed445a93ac
