#Thu Sep 15 10:57:59 IST 2016
lib/com.ibm.ws.messaging.common_1.0.12.jar=512930ba498637ecd3d6208539ec31b2
lib/com.ibm.ws.resource_1.0.12.jar=689cb537b53931bc7008bb8267cf60fb
lib/com.ibm.ws.messaging.jms.common_1.0.12.jar=8ce6c5e436f3ede48972bb278493e9eb
lib/com.ibm.ws.messaging.jms-1.1_1.0.12.jar=01fd390774ba201a69cb57b1c8407e35
lib/features/wasJmsClient-1.1.mf=70d0cd0ffaf77fdd29a50d0d7d8936b2
lib/com.ibm.ws.messaging.comms.client_1.0.12.jar=f6a7c9ba67089076f381a489a86744f7
lib/com.ibm.ws.messaging.utils_1.0.12.jar=86beb443972f216e6f487a99adc51cb4
