#Wed Jun 15 10:05:38 IST 2016
lib/com.ibm.ws.security.credentials_1.0.12.jar=d513d71e7154a1738bce30a926b86deb
lib/com.ibm.ws.security.token.ltpa_1.0.12.jar=7602a13a4b4aae2601ba9193b3355b0f
lib/com.ibm.websphere.security_1.0.12.jar=a00cf32cde46e0420f7f106dca4b088c
lib/com.ibm.ws.security.token_1.0.12.jar=e3f4fdffee7b0466a2c2c3df04cdb82d
lib/features/ltpa-1.0.mf=cb3c07331d4abfbd21a90b0ca0e26a2b
lib/com.ibm.ws.security.credentials.ssotoken_1.0.12.jar=b7723c4fdb30e67947aa589d137a0ede
