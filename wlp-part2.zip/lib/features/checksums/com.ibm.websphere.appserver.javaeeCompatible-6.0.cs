#Wed Jun 15 10:10:13 IST 2016
lib/com.ibm.ws.javaee.version_1.0.12.jar=213e21405c201c22e30b836efb6f6265
lib/features/javaeeCompatible-6.0.mf=fa8178749cb354b23fb5349b9c73810e
