#Thu Sep 15 11:03:06 IST 2016
lib/com.ibm.ws.jdbc.management.j2ee_1.0.12.jar=52bf54e25326e9016bdbcfc6bdf1e8a6
lib/features/jdbcJ2eeManagement-1.0.mf=86d9e5bc1d8cb06eb412ced44502ef16
