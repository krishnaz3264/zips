#Thu Sep 15 11:03:15 IST 2016
lib/com.ibm.ws.transaction.management_1.0.12.jar=37fd25b58aa8a6b863bc44ae3ab6f321
lib/features/j2eeManagement1.1-transaction1.2.mf=85c568e4fd65847e7bcf9f4e894096e9
