#Sat Feb 27 17:09:05 GMT 2016
lib/features/com.ibm.websphere.appserver.internal.jca-1.6.mf=102377013e98925ed627592b04bb1bf7
lib/com.ibm.ws.jca.feature_1.0.12.jar=6a2caf0cca73eee297691b5f97e79311
lib/com.ibm.ws.jca.utils_1.0.12.jar=e5850bc65acef6de9c9ae61f1fd78e98
lib/com.ibm.ws.jca_1.0.12.jar=bac608f8dca54f50e516f489995ca41a
