#Sat Feb 27 17:09:04 GMT 2016
lib/com.ibm.ws.jca.cm_1.0.12.jar=dca71e21e9f72d3d0afbf75b9faeffe8
lib/com.ibm.ws.tx.zos_1.0.12.jar=c793e224107a6a43cba9b3b6ce44ce5b
lib/features/connectionManagement-1.0.mf=40db71cdf84df81a3ce317039e08f99f
