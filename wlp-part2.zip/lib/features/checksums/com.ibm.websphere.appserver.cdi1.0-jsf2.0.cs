#Thu Sep 15 10:41:55 IST 2016
lib/features/cdi1.0-jsf2.0.mf=7d68a1dde925ac42eb2d54b083820690
lib/com.ibm.ws.openwebbeans-jsf.1.1.6_1.0.12.jar=4e4a44d2706536f8f9ed6e41211649e2
