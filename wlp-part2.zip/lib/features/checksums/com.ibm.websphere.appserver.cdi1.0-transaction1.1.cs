#Thu Sep 15 10:41:55 IST 2016
lib/com.ibm.ws.openwebbeans-transaction.1.1.6_1.0.12.jar=678bc0dda906db45cec06c33418f07dc
lib/com.ibm.ws.openwebbeans-ee.1.1.6_1.0.12.jar=97209ebebb5bf9982ceb11d7bdf69248
lib/features/cdi1.0-transaction1.1.mf=115f2dd00bdd9373bb6ba830de72056a
