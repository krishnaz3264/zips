#Sat Feb 27 17:09:06 GMT 2016
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.anno_1.0-javadoc.zip=d3fa3d0fc091baf2fe547e8bdcd67b8c
lib/com.ibm.ws.anno_1.0.12.jar=01c850139c31604ddd065ecc49a591e0
dev/spi/ibm/com.ibm.websphere.appserver.spi.anno_1.0.12.jar=b66b89be118af584337e70d8f22a5741
lib/features/anno-1.0.mf=3396e266c08c2600beff23db02668c1f
